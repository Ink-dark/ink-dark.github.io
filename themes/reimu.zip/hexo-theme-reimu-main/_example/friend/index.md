---
title: 友情链接
comments: true
---

## 本站信息
- 站名： 拔剑Sketon
- 站长： 拔剑Sketon
- 地址： https://d-sketon.top/
- 备用地址：https://d-sketon.github.io/

## 申请方法
- 添加本站后，在本页留言，格式如下

~~~yml
```yml
- name: #您的名字
  url: #您的网址
  desc: #简短描述
  image: #一张图片
```
~~~

## 小伙伴们
{% friendsLink friend/_data.yml %}
